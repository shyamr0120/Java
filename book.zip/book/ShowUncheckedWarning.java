public class ShowUncheckedWarning {
  public static void main(String[] args) {
    java.util.ArrayList list = 
      new java.util.ArrayList();
    list.add("Java Programming");
  }
}